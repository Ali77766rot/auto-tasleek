package com.autotasleek.keyboard

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection
import com.autotasleek.R

class CustomKeyboardService : InputMethodService(), KeyboardView.OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var keyboard: Keyboard

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_layout, null) as KeyboardView
        keyboard = Keyboard(this, R.xml.arabic_keyboard)
        keyboardView.keyboard = keyboard
        keyboardView.setOnKeyboardActionListener(this)
        return keyboardView
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val inputConnection: InputConnection? = currentInputConnection
        if (inputConnection != null) {
            when (primaryCode) {
                Keyboard.KEYCODE_DELETE -> {
                    inputConnection.deleteSurroundingText(1, 0)
                }
                Keyboard.KEYCODE_DONE -> {
                    inputConnection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                }
                // Handle spacebar with Spies feature (placeholder for now)
                // Will be implemented later with shared preferences or similar
                32 -> { // Spacebar keycode
                    inputConnection.commitText(" ", 1)
                }
                else -> {
                    val code = primaryCode.toChar()
                    inputConnection.commitText(code.toString(), 1)
                }
            }
        }
    }

    override fun onText(text: CharSequence?) {
        // Not used
    }

    override fun swipeLeft() {
        // Not used
    }

    override fun swipeRight() {
        // Not used
    }

    override fun swipeDown() {
        // Not used
    }

    override fun swipeUp() {
        // Not used
    }

    override fun onPress(primaryCode: Int) {
        // Not used
    }

    override fun onRelease(primaryCode: Int) {
        // Not used
    }
}
