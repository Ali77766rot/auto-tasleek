package com.autotasleek.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PhraseDao {
    @Query("SELECT * FROM phrases ORDER BY id DESC")
    fun getAllPhrases(): Flow<List<PhraseEntity>>

    @Insert
    suspend fun insertPhrase(phrase: PhraseEntity)

    @Query("DELETE FROM phrases WHERE id = :phraseId")
    suspend fun deletePhrase(phraseId: Int)
}
