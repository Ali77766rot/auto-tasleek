package com.autotasleek

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.autotasleek.accessibility.AutomationAccessibilityService
import com.autotasleek.data.AppDatabase
import com.autotasleek.data.PhraseEntity
import com.autotasleek.ui.theme.AutoTasleekTheme
import com.autotasleek.ui.theme.NeonBlack
import com.autotasleek.ui.theme.NeonGreen
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

// ViewModel for managing UI state and interacting with the database
class MainViewModel(applicationContext: Context) : ViewModel() {
    private val db = Room.databaseBuilder(
        applicationContext,
        AppDatabase::class.java,
        "phrase-database"
    ).build()
    private val phraseDao = db.phraseDao()

    val allPhrases: Flow<List<PhraseEntity>> = phraseDao.getAllPhrases()

    var currentPhraseInput by mutableStateOf(TextFieldValue(""))
        private set

    var typingDelay by mutableStateOf(50f) // Default 50ms
        private set

    var showStoredPhrases by mutableStateOf(false)
        private set

    var spiesFeatureEnabled by mutableStateOf(false)
        private set

    var specialSymbol by mutableStateOf("~")
        private set

    var customSpacing by mutableStateOf(3) // Default 3 spaces
        private set

    fun updateCurrentPhraseInput(newValue: TextFieldValue) {
        currentPhraseInput = newValue
    }

    fun updateTypingDelay(newValue: Float) {
        typingDelay = newValue
    }

    fun toggleShowStoredPhrases() {
        showStoredPhrases = !showStoredPhrases
    }

    fun toggleSpiesFeature() {
        spiesFeatureEnabled = !spiesFeatureEnabled
    }

    fun updateSpecialSymbol(symbol: String) {
        specialSymbol = symbol
    }

    fun updateCustomSpacing(spacing: Int) {
        customSpacing = spacing
    }

    suspend fun savePhrase(phrase: String) {
        if (phrase.isNotBlank()) {
            phraseDao.insertPhrase(PhraseEntity(text = phrase))
            currentPhraseInput = TextFieldValue("") // Clear input after saving
        }
    }

    suspend fun deletePhrase(phraseId: Int) {
        phraseDao.deletePhrase(phraseId)
    }

    // Factory for ViewModel
    companion object {
        fun provideFactory(applicationContext: Context): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return MainViewModel(applicationContext) as T
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AutoTasleekTheme {
                val context = LocalContext.current
                val viewModel: MainViewModel = viewModel(factory = MainViewModel.provideFactory(context))
                MainScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeonBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Input Field
        OutlinedTextField(
            value = viewModel.currentPhraseInput,
            onValueChange = { viewModel.updateCurrentPhraseInput(it) },
            label = { Text(stringResource(R.string.enter_phrase_hint), color = NeonGreen) },
            modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = NeonGreen,
                cursorColor = NeonGreen,
                textColor = NeonGreen
            )
        )
        Spacer(Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            // Send/Save Button
            Button(
                onClick = {
                    coroutineScope.launch {
                        viewModel.savePhrase(viewModel.currentPhraseInput.text)
                        // Trigger accessibility service to type the phrase
                        if (isAccessibilityServiceEnabled(context)) {
                            val intent = Intent(context, AutomationAccessibilityService::class.java)
                            intent.action = "com.autotasleek.TYPE_PHRASE"
                            intent.putExtra("phrase", viewModel.currentPhraseInput.text)
                            intent.putExtra("delay", viewModel.typingDelay.toLong())
                            context.startService(intent)
                        } else {
                            // Prompt user to enable accessibility service
                            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            ) {
                Text(stringResource(R.string.send_button), color = NeonBlack, fontSize = 18.sp)
            }

            // Store Button
            Button(
                onClick = { viewModel.toggleShowStoredPhrases() },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                modifier = Modifier.weight(1f).padding(start = 8.dp)
            ) {
                Text(stringResource(R.string.store_button), color = NeonBlack, fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(16.dp))

        // Speed Slider
        Text(stringResource(R.string.speed_slider_label) + ": ${viewModel.typingDelay.toInt()}ms", color = NeonGreen)
        Slider(
            value = viewModel.typingDelay,
            onValueChange = { viewModel.updateTypingDelay(it) },
            valueRange = 3f..350f,
            steps = 347, // 350 - 3 = 347 steps
            colors = SliderDefaults.colors(
                thumbColor = NeonGreen,
                activeTrackColor = NeonGreen,
                inactiveTrackColor = NeonGreen.copy(alpha = 0.3f)
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        // Spies Feature Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(stringResource(R.string.spies_feature_toggle), color = NeonGreen, fontSize = 18.sp)
            Switch(
                checked = viewModel.spiesFeatureEnabled,
                onCheckedChange = { viewModel.toggleSpiesFeature() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonBlack,
                    checkedTrackColor = NeonGreen,
                    uncheckedThumbColor = NeonGray,
                    uncheckedTrackColor = NeonBlack
                )
            )
        }

        if (viewModel.spiesFeatureEnabled) {
            Spacer(Modifier.height(8.dp))
            // Special Symbol Input
            OutlinedTextField(
                value = viewModel.specialSymbol,
                onValueChange = { viewModel.updateSpecialSymbol(it) },
                label = { Text(stringResource(R.string.special_symbol_label), color = NeonGreen) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = NeonGreen,
                    cursorColor = NeonGreen,
                    textColor = NeonGreen
                )
            )
            Spacer(Modifier.height(8.dp))
            // Custom Spacing Options
            Text(stringResource(R.string.custom_spacing_label), color = NeonGreen, fontSize = 16.sp)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(3, 4, 5, 7).forEach { spacing ->
                    Button(
                        onClick = { viewModel.updateCustomSpacing(spacing) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (viewModel.customSpacing == spacing) NeonGreen else NeonGray
                        ),
                        modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
                    ) {
                        Text("$spacing", color = NeonBlack)
                    }
                }
            }
        }

        // Stored Phrases List
        if (viewModel.showStoredPhrases) {
            Spacer(Modifier.height(16.dp))
            val phrases by viewModel.allPhrases.collectAsState(initial = emptyList())
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(NeonGray, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                items(phrases) {
                    PhraseItem(phrase = it) {
                        coroutineScope.launch { viewModel.deletePhrase(it.id) }
                    }
                }
            }
        }
    }
}

@Composable
fun PhraseItem(phrase: PhraseEntity, onDelete: (PhraseEntity) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .background(NeonBlack, RoundedCornerShape(4.dp))
            .clickable { /* Optionally type phrase on click */ }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(phrase.text, color = NeonGreen, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Button(
            onClick = { onDelete(phrase) },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
            modifier = Modifier.wrapContentWidth()
        ) {
            Text("X", color = Color.White)
        }
    }
}

// Helper function to check if accessibility service is enabled
fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val accessibilityServiceId = context.packageName + "/" + AutomationAccessibilityService::class.java.name
    val enabledServices = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
    return enabledServices?.contains(accessibilityServiceId) == true
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    AutoTasleekTheme {
        // For preview, we can't easily provide a real ViewModel with database access.
        // A mock ViewModel or a simplified UI without database interaction would be needed.
        // For now, we'll just show the basic structure.
        Text("Preview not fully functional with ViewModel", color = NeonGreen)
    }
}
