package com.autotasleek.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Neon Theme Colors
val NeonBlack = Color(0xFF000000)
val NeonGreen = Color(0xFF00FF00)
val NeonGreenVariant = Color(0xFF39FF14) // A slightly different shade for accents
val NeonGray = Color(0xFF222222)
