package com.autotasleek.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.util.Log
import kotlinx.coroutines.* // Import for coroutines

class AutomationAccessibilityService : AccessibilityService() {

    private val TAG = "AutoTasleekAccessibility"
    private var typingDelay: Long = 50 // Default typing delay in ms
    private var phraseToType: String? = null
    private var isTypingActive = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val rootNode = rootInActiveWindow ?: return

        // Log event type for debugging
        Log.d(TAG, "Accessibility Event: ${AccessibilityEvent.eventTypeToString(event.eventType)}")

        // Find editable text fields and send buttons
        val editableNodes = findEditableNodes(rootNode)
        val sendButtons = findSendButtons(rootNode)

        // Example: If a phrase is set and not currently typing, try to type it
        if (phraseToType != null && !isTypingActive) {
            if (editableNodes.isNotEmpty()) {
                val targetNode = editableNodes.first()
                Log.d(TAG, "Found editable node: ${targetNode.viewIdResourceName}")
                startTypingPhrase(targetNode, phraseToType!!)
                phraseToType = null // Clear phrase after starting to type
            }
        }
    }

    private fun findEditableNodes(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val editableNodes = mutableListOf<AccessibilityNodeInfo>()
        if (node.isEditable) {
            editableNodes.add(node)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                editableNodes.addAll(findEditableNodes(child))
                child.recycle()
            }
        }
        return editableNodes
    }

    private fun findSendButtons(node: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val sendButtons = mutableListOf<AccessibilityNodeInfo>()
        val nodeText = node.text?.toString()?.toLowerCase(java.util.Locale.ROOT)
        val nodeClassName = node.className?.toString()

        // Common send button identifiers (can be expanded)
        if (node.isClickable && (nodeText == "send" || nodeText == "ارسال" || nodeClassName?.contains("Button") == true || nodeClassName?.contains("ImageButton") == true)) {
            sendButtons.add(node)
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                sendButtons.addAll(findSendButtons(child))
                child.recycle()
            }
        }
        return sendButtons
    }

    private fun startTypingPhrase(targetNode: AccessibilityNodeInfo, phrase: String) {
        isTypingActive = true
        CoroutineScope(Dispatchers.IO).launch {
            for (char in phrase) {
                val arguments = android.os.Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, char.toString())
                }
                targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
                delay(typingDelay)
            }
            isTypingActive = false
        }
    }

    // Method to set the phrase to be typed from MainActivity
    fun setPhraseToType(phrase: String) {
        this.phraseToType = phrase
    }

    // Method to set typing delay from MainActivity
    fun setTypingDelay(delay: Long) {
        this.typingDelay = delay
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
        isTypingActive = false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
        val info = serviceInfo
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED or
                AccessibilityEvent.TYPE_VIEW_FOCUSED or
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_WINDOW_CONTENT
        serviceInfo = info
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Accessibility service destroyed")
        isTypingActive = false
    }
}
