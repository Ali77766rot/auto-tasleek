package com.autotasleek.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [PhraseEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun phraseDao(): PhraseDao
}
